const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');

const cors = require('cors');
const app = express();

app.use(cors())
app.use(express.static('public'))
app.use(bodyParser.json());

app.post('/get-headers', async (req, res) => {
    try {

        const response = await axios.post('https://chimpu.xyz/api/post.php', { phonenumber: req.body.phonenumber });
        console.log('Response Headers:', response.headers);
        const phoneorigen = response.headers.phoneorigen;
        res.json({ msg: phoneorigen});
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

app.listen(3000, () => {
    console.log(`Server is running `)
});
